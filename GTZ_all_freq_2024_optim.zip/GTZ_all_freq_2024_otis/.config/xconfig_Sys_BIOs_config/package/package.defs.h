/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef xconfig_Sys_BIOs_config__
#define xconfig_Sys_BIOs_config__



#endif /* xconfig_Sys_BIOs_config__ */ 
